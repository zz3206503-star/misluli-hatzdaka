'use strict';
const el=id=>document.getElementById(id), labels={wk:'Weekdays · Monday to Friday',sun:'Sunday',mon:'Monday',tue:'Tuesday',wed:'Wednesday',thu:'Thursday',fri:'Friday',sat:'Shabbat',addressOptions:'Synagogue address',nameEn:'English synagogue name'};
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const list=v=>Array.isArray(v)?v:[v], fmt=v=>list(v).length?list(v).map(x=>'<bdi>'+esc(x)+'</bdi>').join(' · '):'No time listed';
const issue=f=>f.visibility!=='full'||f.add?.length||f.missing?.length;
const storage='minyan-review-unified-v3';
function readLocal(key){try{return JSON.parse(localStorage.getItem(key)||'{}')||{}}catch{return {}}}
const cached=readLocal(storage);let choices={...{"lu0151/addressOptions": "photo", "lu0154/nameEn": "both", "lu0155/wk": "photo", "lu0159/sun": "app", "lu0159/addressOptions": "photo", "lu0167/nameEn": "both", "lu0169/nameEn": "both", "lu0170/addressOptions": "photo", "lu0174/nameEn": "both"},...cached.choices},outbox=cached.outbox||{},busy=false,loaded=false;
function persist(){try{localStorage.setItem(storage,JSON.stringify({choices,outbox,place:picker.value}));return true}catch{return false}}
const id=(p,f)=>p.id+'/'+f.key;
const valid=['app','photo','both'];
const ordered=places.slice().sort((a,b)=>Number(!a.fields.some(f=>f.add?.length))-Number(!b.fields.some(f=>f.add?.length)));
const picker=el('place');for(const p of ordered){picker.add(new Option(p.he+' · '+p.name,p.id))}
if(ordered.some(p=>p.id===cached.place))picker.value=cached.place;
function current(){return places.find(p=>p.id===picker.value)}
function outcome(f,c){
 const base=list(f.base),photo=list(f.photo);
 if(c==='app'||f.visibility==='hidden')return base;
 if(c==='photo'&&!f.incomplete&&f.visibility!=='partial')return photo;
 return [...new Set([...base,...photo])].sort((a,b)=>/^\d\d:\d\d$/.test(a)?a.localeCompare(b):0);
}
function diff(f){
 if(f.visibility==='hidden')return 'This day is outside the photo. Selecting the photo flags it for verification and keeps the current value.';
 if(f.visibility==='duplicate')return 'The time appears twice in the photo. It may refer to two minyanim.';
 if(f.visibility==='both')return 'The app has two addresses. The photo shows one.';
 if(f.visibility==='name')return 'The English name differs between the sources.';
 if(f.missing?.length)return 'Times missing from the photo '+f.missing.join(' · ');
 const add=f.add?.length?'Times in the photo missing from the app: '+f.add.join(' · '):'Visible times match.';
 return add+(f.visibility==='partial'?' Part of the day is cropped. Other times will be kept.':'');
}
function card(p,f){
 const k=id(p,f),choice=choices[k],same=!issue(f);
 return '<article><h3>'+labels[f.key]+'</h3><table><thead><tr><th>Right · App</th><th>Left · GoDavening</th></tr></thead><tbody><tr><td>'+fmt(f.base)+'</td><td>'+(f.visibility==='hidden'?'Outside the photo':fmt(f.photo))+'</td></tr></tbody></table><p class="diff"><strong>Difference</strong> · '+esc(diff(f))+'</p><div class="choices">'+[['app','Use right'],['photo','Use left'],['both','Keep both']].map(([v,t])=>'<button data-k="'+f.key+'" data-choice="'+v+'" aria-pressed="'+(choice===v)+'">'+(choice===v?'✓ ':'')+t+'</button>').join('')+'</div><p class="result" aria-live="polite">'+(choice?'Selected: '+({app:'App',photo:'GoDavening',both:'Both in one row'})[choice]+' · '+fmt(outcome(f,choice)):'Pending')+'</p></article>';
}
function updateCount(){el('status').textContent=Object.keys(choices).length+' rows selected in the report';}
function draw(){
 const p=current(),issues=p.fields.filter(issue),same=p.fields.filter(f=>!issue(f));
 el('sheet').innerHTML='<div class="intro"><h2>'+esc(p.he)+'</h2><div class="ident"><bdi>'+esc(p.name)+'</bdi> · <bdi>'+esc(p.address)+'</bdi></div><details class="photos"><summary>Open original photo</summary>'+p.photos.map(n=>'<img loading="lazy" src="photos/'+n+'.webp" alt="Photo '+n+'">').join('')+'</details></div>'+
 (p.fields.length?'':'<p>No further approval needed.</p>')+issues.map(f=>card(p,f)).join('')+(same.length?'<details '+(!issues.length?'open':'')+'><summary>Matching rows ('+same.length+')</summary>'+same.map(f=>card(p,f)).join('')+'</details>':'')+'<button id="next">Next synagogue</button>';
 el('next').onclick=()=>{picker.selectedIndex=(picker.selectedIndex+1)%ordered.length;persist();draw();window.scrollTo(0,0)};updateCount();
}
picker.onchange=()=>{persist();draw()};
el('sheet').onclick=e=>{const b=e.target.closest('[data-choice]');if(!b)return;const p=current(),f=p.fields.find(x=>x.key===b.dataset.k);choices[id(p,f)]=b.dataset.choice;outbox[id(p,f)]=b.dataset.choice;saved();b.closest('article').outerHTML=card(p,f);updateCount();el('fallback').hidden=true};
function output(){const decisions=[];for(const p of places)for(const f of p.fields){const c=choices[id(p,f)];if(valid.includes(c))decisions.push({placeId:p.id,placeName:p.name,field:f.key,choice:c,app:f.base,photo:f.photo,visibility:f.visibility,selectedValues:outcome(f,c),requiresVerification:f.visibility==='hidden'||f.visibility==='partial'||f.visibility==='duplicate',sameRow:c==='both'})}return JSON.stringify({format:'minyan-review-weekgroups-v3',baseVersion:10,decisions},null,2)}
el('copy').onclick=async()=>{const text=output();try{await navigator.clipboard.writeText(text);el('msg').textContent='Decisions copied. Paste them in the chat.'}catch{const b=el('fallback');b.hidden=false;b.value=text;b.select();el('msg').textContent='Press and hold the text and select Copy.'}};
el('save').onclick=()=>{const u=URL.createObjectURL(new Blob([output()],{type:'application/json'})),a=document.createElement('a');a.href=u;a.download='my-minyan-decisions.json';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),15000);el('msg').textContent='Attach the decisions file to the chat.'};

const sync=el('sync');
function saved(){sync.textContent=persist()?'Saved in this browser. You can download a backup.':'Browser storage blocked. Download a backup.'}
el('restore').onchange=async e=>{
 try{
  const data=JSON.parse(await e.target.files[0].text());
  if(data.format!=='minyan-review-weekgroups-v3'||!Array.isArray(data.decisions))throw Error();
  for(const row of data.decisions){
   const p=places.find(p=>p.id===row.placeId);
   if(p?.fields.some(f=>f.key===row.field)&&valid.includes(row.choice))choices[row.placeId+'/'+row.field]=row.choice;
  }
  saved();draw();
 }catch{el('msg').textContent='Could not read the decisions file.'}
 e.target.value='';
};
draw();saved();
