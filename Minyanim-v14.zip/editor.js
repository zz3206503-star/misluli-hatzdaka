/* Local edits are keyed by the original catalog ID for later publication. */
function startPlaceEditor(places, refresh) {
  const key = 'minyan-place-edits-v1';
  const byId = new Map(places.map(p => [p.id, p]));
  const base = new Map();
  const dialog = document.getElementById('placeEditor');
  const field = id => document.getElementById(id);
  const dayNames = {all:'רגיל', wk:'שני–שישי', sun:'ראשון', mon:'שני', tue:'שלישי', wed:'רביעי', thu:'חמישי', fri:'שישי', sat:'שבת', 'mon-thu':'שני וחמישי', 'mon-thu-offset':'רגיל, שני וחמישי 10 דקות מוקדם יותר'};
  let current, editingDays, prior;
  function read() { return JSON.parse(localStorage.getItem(key) || '{}'); }
  function scheduleText(p, d) {return [...new Set((p.schedule || []).filter(e => e.day === d).map(e => e.time))].sort().join(', ');}
  function original(p) {
    if (!base.has(p.id)) base.set(p.id, structuredClone(p));
    return base.get(p.id);
  }
  function apply(p, patch) {
    const src = original(p);
    Object.assign(p, structuredClone(src));
    for (const k of ['nameHe','nameEn','address']) if (k in patch) p[k] = patch[k];
    if ('address' in patch && patch.address !== src.address) {
      p.lat = p.lon = p.mapUrl = p.addressOptions = null;
      p.addressLocated = false; p.editedAddress = true;
    } else {
      p.editedAddress = false;
      p.addressOptions = src.addressOptions; p.mapUrl = src.mapUrl;
    }
    for (const [day, times] of Object.entries(patch.days || {})) {
      p.schedule = (p.schedule || []).filter(e => e.day !== day).concat(times.map(time => ({day,time,source:'עריכה מקומית'})));
    }
    p.editNote = patch.note || '';
  }
  function reportError() {field('editInfo').textContent=uiText('השמירה במכשיר נכשלה. בדוק שהדפדפן מאפשר אחסון ונסה שוב.');}
  try { for (const [id,entry] of Object.entries(read())) if (byId.has(id)) apply(byId.get(id),entry.changes); }
  catch {field('editSummary').textContent=uiText('קריאת השינויים המקומיים נכשלה.');}
  function pairOptions(selected) {
    const query=field('otherSearch').value.trim().toLowerCase();
    const list=field('otherPlace'); list.replaceChildren(new Option(uiText('בחר את הכרטיס השני'),''));
    const options=places.filter(p=>p.id!==current.id && (p.id===selected || (query && [p.name,p.nameHe,p.nameEn,p.address,...p.localities].join(' ').toLowerCase().includes(query)))).slice(0,80);
    if(selected && !options.some(p=>p.id===selected) && byId.has(selected)) options.unshift(byId.get(selected));
    for(const p of options) list.add(new Option([p.nameHe||p.name,p.nameEn,p.address,p.localities[0],p.id].filter(Boolean).join(' · '),p.id));
    list.value=selected || '';
  }
  function open(p) {
    current=p;original(p);field('editLanguage').value=document.documentElement.lang;
    try {prior=JSON.stringify(read()[p.id] || null);}catch{alert(uiText('אין גישה לשמירה במכשיר'));return;}
    const entry=JSON.parse(prior);
    field('editTitle').textContent=uiText('עריכת '+(document.documentElement.lang==='he'?(p.nameHe||p.name):(p.nameEn||p.name)));
    for(const k of ['nameHe','nameEn','address']) field('edit-'+k).value=p[k]||'';
    field('editNote').value=p.editNote||'';field('otherSearch').value='';pairOptions(entry?.changes.duplicateOf);
    field('editInfo').textContent='';editingDays=field('editDays');editingDays.replaceChildren();
    for(const [day,label] of Object.entries(dayNames)) {
      if(!['wk','sun'].includes(day) && !(p.schedule||[]).some(e=>e.day===day) && !entry?.changes.days?.[day]) continue;
      const row=document.createElement('label'), input=document.createElement('input');
      row.textContent=uiText(label);input.dir='ltr';input.dataset.day=day;input.value=scheduleText(p,day);row.append(input);editingDays.append(row);
    }
    photoTools.controls(p,refresh);dialog.showModal();
  }
  field('editLanguage').onchange=()=>MaslulI18n.set(field('editLanguage').value);
  window.addEventListener('maslul-languagechange',()=>{
    field('editSummary').textContent='';if(!dialog.open)return;
    field('editLanguage').value=document.documentElement.lang;
    field('editTitle').textContent=uiText('עריכת '+(document.documentElement.lang==='he'?current.nameHe:current.nameEn));
    for(const input of editingDays.querySelectorAll('input'))input.parentNode.firstChild.nodeValue=uiText(dayNames[input.dataset.day]);
    pairOptions(field('otherPlace').value);field('editInfo').textContent='';
    photoTools.relabel();
  });
  const requested=new URLSearchParams(location.search).get('edit');
  if(requested&&byId.has(requested))open(byId.get(requested));
  field('otherSearch').oninput=()=>pairOptions(field('otherPlace').value);
  field('cancelEdit').onclick=()=>dialog.close();
  document.addEventListener('click',e=>{const b=e.target.closest('[data-edit]');if(b && byId.has(b.dataset.edit))open(byId.get(b.dataset.edit));});
  field('editForm').onsubmit=e=>{
    e.preventDefault();
    const src=original(current),changes={},before={};
    for(const k of ['nameHe','nameEn','address']) {
      const v=field('edit-'+k).value.trim();
      if(v!==(src[k]||'')){changes[k]=v;before[k]=src[k]||'';}
    }
    for(const input of editingDays.querySelectorAll('input')) {
      const day=input.dataset.day, tokens=input.value.trim().split(/[,;\s]+/).filter(Boolean);
      if(tokens.some(t=>!/^([01]\d|2[0-3]):[0-5]\d$/.test(t))){field('editInfo').textContent=uiText('הזן כל שעה בצורת 07:30, והפרד בין השעות בפסיקים.');input.focus();return;}
      const values=[...new Set(tokens)].sort();
      if(values.join(', ')!==scheduleText(src,day)){(changes.days??={})[day]=values;(before.days??={})[day]=scheduleText(src,day);}
    }
    const note=field('editNote').value.trim(),second=field('otherPlace').value;
    if(note)changes.note=note;if(second)changes.duplicateOf=second;
    try {
      const all=read();
      if(JSON.stringify(all[current.id]||null)!==prior){field('editInfo').textContent=uiText('הרשומה השתנתה בלשונית אחרת. סגור ופתח את העריכה מחדש.');return;}
      if(Object.keys(changes).length) all[current.id]={id:current.id,originalName:src.name,city:src.city,before,changes};
      else delete all[current.id];
      localStorage.setItem(key,JSON.stringify(all));
    } catch {reportError();return;}
    apply(current,changes);dialog.close();refresh();
  };
  field('exportEdits').onclick=async()=>{
    try {
      const edits=Object.values(read()), photos=await photoTools.all();if(!edits.length&&!photos.length){field('editSummary').textContent=uiText('עדיין לא נשמרו עריכות במכשיר הזה.');return;}
      const u=URL.createObjectURL(new Blob([JSON.stringify({format:key,baseVersion:18,edits,photos},null,2)],{type:'application/json'}));
      const a=document.createElement('a');a.href=u;a.download='minyanim-edits.json';a.click();setTimeout(()=>URL.revokeObjectURL(u),3000);
      field('editSummary').textContent=uiText('הקובץ כולל '+new Set([...edits,...photos].map(r=>r.id)).size+' רשומות ערוכות. אפשר לשלוח אותו בצ׳אט לעדכון האתר.');
    }catch{field('editSummary').textContent=uiText('הורדת השינויים נכשלה.');}
  };
}
