(() => {
  const records = window.buildingPhotoData;
  const escape = value => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const lang = () => document.documentElement.lang.split('-')[0];
  const labels = {
    he: ['הגדלת תמונת המבנה','סגירה','מקור התמונה','הותאם בגודל'],
    en: ['Enlarge building photo','Close','Image source','Resized'],
    es: ['Ampliar foto del edificio','Cerrar','Fuente de la imagen','Tamaño ajustado']
  };
  const label = i => (labels[lang()] || labels.he)[i];
  const photoSrc = (r, small) => r.localImage || r.photoUrl || ('building-photos/' + r.key + (small ? '-sm' : '') + '.webp');
  const onlineLabel = () => ({he:'צילום מקוון',en:'Online photo',es:'Foto en línea'}[lang()] || 'צילום מקוון');
  const thumb = id => {
    const r = records[id];
    if (!r) return '';
    return `<button type="button" class="buildingThumb" data-building="${escape(id)}" aria-label="${label(0)} · ${escape(r.name)}"><img loading="lazy" decoding="async" alt="${escape(r.name)}" referrerpolicy="no-referrer" src="${escape(photoSrc(r,true))}">${r.photoUrl ? "<small>"+onlineLabel()+"</small>" : ""}</button>`;
  };
  window.minyanPhotos = {thumb};
  document.addEventListener('click', e => {
    const button = e.target.closest('[data-building]');
    if (!button) return;
    const r = records[button.dataset.building];
    if (!r) return;
    e.preventDefault();
    e.stopPropagation();
    const dialog = document.createElement('dialog');
    dialog.className = 'buildingDialog';
    dialog.setAttribute('aria-label', r.name);
    dialog.innerHTML = `<button type="button" autofocus>${label(1)} ×</button><h2 dir="auto">${escape(r.name)}</h2><img alt="${escape(r.name)}" referrerpolicy="no-referrer" src="${escape(photoSrc(r,false))}"><p dir="auto">${escape(r.city)}</p><p dir="auto">${escape(r.credit)} · ${r.licenseUrl ? '<a href="'+escape(r.licenseUrl)+'" target="_blank" rel="noopener">'+escape(r.license)+'</a>' : escape(r.license)} · ${r.photoUrl ? onlineLabel() : label(3)} · <a href="${escape(r.source)}" target="_blank" rel="noopener">${label(2)}</a></p>`;
    const edit=document.createElement('button');edit.type='button';edit.textContent=photoTools.t('photo');
    edit.onclick=()=>{dialog.close();if(document.getElementById('placeEditor')){
      const trigger=document.createElement('button');trigger.dataset.edit=button.dataset.building;document.body.append(trigger);trigger.click();trigger.remove();
    }else location.assign('index.html?edit='+encodeURIComponent(button.dataset.building));};
    if(r.localImage){dialog.querySelector('p:last-child').textContent=photoTools.t('own');}
    if (r.photoUrl) {
      const img = dialog.querySelector('img');
      img.addEventListener('error', () => {
        const msg = document.createElement('p');
        msg.textContent = ({he:'טעינת הצילום נכשלה. אפשר לפתוח את מקור התמונה בקישור למטה.', en:'Photo unavailable. Open the image source below.', es:'Foto no disponible. Abre la fuente de la imagen.'})[lang()] || 'Photo unavailable.';
        img.replaceWith(msg);
      }, {once:true});
    }
    dialog.querySelector('button').onclick = () => dialog.close();
    dialog.onclick = evt => { if (evt.target === dialog) dialog.close(); };
    dialog.addEventListener('close', () => { dialog.remove(); if (button.isConnected) button.focus(); });
    dialog.append(edit);document.body.append(dialog);
    dialog.showModal();
  }, true);
  const gallery = document.querySelector('#buildingGallery');
  if (gallery) {
    const search = document.querySelector('#buildingSearch');
    const render = () => {
      const q = search.value.trim().toLowerCase();
      const entries = Object.entries(records).filter(([,r]) => [r.name,r.he,r.city].join(' ').toLowerCase().includes(q));
      document.querySelector('#photoCount').textContent = entries.length.toLocaleString(lang()) + ' ' + uiText('כרטיסים עם צילום');
      gallery.innerHTML = entries.map(([id,r]) => `<article>${thumb(id)}<h2 dir="auto">${escape(r.he || r.name)}</h2><p dir="auto">${escape(r.name)}</p><p dir="auto">${escape(r.city)}</p></article>`).join('');
    };
    search.addEventListener('input', render);
    photoTools.ready.then(render);
  }
})();
