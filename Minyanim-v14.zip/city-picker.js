(()=>{
 const normalize=s=>s.normalize('NFKD').replace(/\p{M}/gu,'').replace(/[’'׳״".‐-]/g,'').trim().toLowerCase();
 const byId=id=>document.getElementById(id);
 const lang=()=>document.documentElement.lang;
 const words={
  citySearch:['חיפוש עיר בעברית או באנגלית','Search cities in Hebrew or English','Buscar ciudades en hebreo o inglés'],
  chooseCity:['בחר עיר','Choose a city','Elegir ciudad'],
  gpsCity:['לפי המיקום שלי (GPS)','My location (GPS)','Mi ubicación (GPS)'],
  closeCity:['סגור','Close','Cerrar'],
  noneCity:['לא נמצאה עיר מתאימה','No matching city','No se encontró ninguna ciudad'],
  moreCity:['הצג עוד ערים','Show more cities','Mostrar más ciudades'],
  cityLetter:['קפיצה לפי אות ראשונה','Jump by first letter','Ir a la inicial'],
  cityResults:['ערים שנמצאו','cities found','ciudades encontradas']
 };
 const t=k=>words[k][{he:0,en:1,es:2}[lang()]??0];
 const names=k=>window.cityNames[k]||[k,k];
 const display=k=>{const [he,en]=names(k);return lang()==='he'?he+' · '+en:en+' · '+he;};
 let list=[],initial='',limit=60;
 function select(k){const native=byId('areaSelect');native.value=k;byId('cityPicker').close();native.dispatchEvent(new Event('change'));labels();}
 function labels(){
  byId('chooseCity').textContent=byId('areaSelect').value?display(byId('areaSelect').value):t('chooseCity');
  document.querySelectorAll('[data-city-label]').forEach(el=>el.textContent=t(el.dataset.cityLabel));
  byId('cityQuery').placeholder=t('citySearch');
 }
 function render(){
  const query=normalize(byId('cityQuery').value),index=initial&&/[א-ת]/.test(initial)?0:initial?1:lang()==='he'?0:1;
  const rows=list.filter(k=>{const n=names(k).map(normalize);return (!initial||n[index].startsWith(normalize(initial)))&&(!query||n.some(x=>x.includes(query)));})
   .sort((a,b)=>names(a)[index].localeCompare(names(b)[index],index?'en':'he'));
  const host=byId('cityResults');host.replaceChildren();
  for(const k of rows.slice(0,limit)){const b=document.createElement('button');b.type='button';b.dir='auto';b.textContent=display(k);b.onclick=()=>select(k);host.append(b);}
  byId('cityMatches').textContent=rows.length?rows.length+' '+t('cityResults'):t('noneCity');
  byId('moreCities').hidden=rows.length<=limit;
  byId('cityLetters').querySelectorAll('button').forEach(b=>b.setAttribute('aria-pressed',String(b.textContent===initial)));
 }
 function setup(cities){
  list=cities;const native=byId('areaSelect');
  const fragment=document.createDocumentFragment();for(const k of list)fragment.append(new Option(display(k),k));native.append(fragment);
  for(const letters of ['אבגדהוזחטיכלמנסעפצקרשת','ABCDEFGHIJKLMNOPQRSTUVWXYZ']){
   const row=document.createElement('div');row.dir=letters[0]==='A'?'ltr':'rtl';
   for(const ch of letters){const b=document.createElement('button');b.type='button';b.textContent=ch;b.onclick=()=>{initial=initial===ch?'':ch;limit=60;byId('cityQuery').value='';render();};row.append(b);}byId('cityLetters').append(row);
  }
  byId('chooseCity').onclick=()=>{initial='';limit=60;byId('cityQuery').value='';labels();render();byId('cityPicker').showModal();};
  byId('gpsCity').onclick=()=>select('');byId('closeCity').onclick=()=>byId('cityPicker').close();
  byId('cityQuery').oninput=()=>{initial='';limit=60;render();};
  byId('moreCities').onclick=()=>{limit+=100;render();};
  window.addEventListener('maslul-languagechange',()=>{labels();if(byId('cityPicker').open)render();});
  labels();
 }
 window.cityPicker={setup,display};
})();
