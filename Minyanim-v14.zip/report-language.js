(()=>{
 let lang='he';try{lang=localStorage.getItem('maslul_language')||'he'}catch{}
 if(!['he','en','es'].includes(lang))lang='he';
 const root=document.documentElement;root.lang=lang;root.dir=lang==='he'?'rtl':'ltr';
 root.style.setProperty('--text-dir',root.dir);
 document.addEventListener('DOMContentLoaded',()=>{
 const sel=document.getElementById('reportLanguage');sel.value=lang;
 sel.onchange=()=>{try{localStorage.setItem('maslul_language',sel.value)}catch{}location.reload()};
 // Translate static controls. Dynamic review scripts render in the selected language.
 for(const e of document.querySelectorAll('header,footer,title,[data-lang-label],body>h1,body>p,body>a,main>h1,main>label,main>a,table th')) localizeStatic(e);
 for(const e of document.querySelectorAll('body>table td:not(:first-child)')){
  localizeStatic(e);for(const b of e.querySelectorAll('bdi'))if(b.textContent.includes('ותיקין'))b.textContent=b.textContent.replaceAll('ותיקין',uiText('ותיקין'));
 }
 });
})();