(()=>{
 const words={
  photoMap:['מפת בתי הכנסת עם תמונות','Synagogue photo map','Mapa de sinagogas con fotos'],
  photo:['עריכת תמונת המבנה','Edit building photo','Editar foto del edificio'],
  choose:['בחר תמונה מהמכשיר','Choose a photo from this device','Elegir una foto del dispositivo'],
  savePhoto:['שמור תמונה במכשיר','Save photo on device','Guardar foto en el dispositivo'],
  removePhoto:['הסר תמונה ושמור במכשיר','Remove photo and save on device','Quitar foto y guardar en el dispositivo'],
  saved:['שינוי התמונה נשמר. הוא ייכלל בהורדת השינויים.','Photo change saved. It will be included in your export.','Cambio guardado. Se incluirá al descargar tus cambios.'],
  failed:['שמירת התמונה נכשלה. בדוק שיש מקום פנוי ונסה צילום JPG או PNG.','Could not save. Check available storage and try a JPG or PNG.','No se pudo guardar. Comprueba el espacio y prueba con JPG o PNG.'],
  missing:['בחר תמונה תחילה','Choose a photo first','Primero elige una foto'],
  own:['תמונה מהמכשיר','Photo from this device','Foto del dispositivo'],
  click:['אתר Click613','Click613 website','Sitio Click613'],
  info:['התקרב במפה כדי לראות צילומי מבנים. לחץ על סמן לפתיחת הכרטיס.','Zoom in to see building photos. Select a marker to open the entry.','Acerca el mapa para ver fotos de los edificios. Pulsa un marcador para abrir la ficha.'],
  only:['הצג רק בתי כנסת עם תמונה','Show only synagogues with a photo','Mostrar solo sinagogas con foto'],
  gps:['המיקום שלי','My location','Mi ubicación'],
  empty:['אין תמונה','No photo','Sin foto']
 };
 const t=k=>words[k][({he:0,en:1,es:2})[document.documentElement.lang]??0];
 const catalog=window.buildingPhotoData;
 const open=new Promise((resolve,reject)=>{
  const req=indexedDB.open('minyan-building-edits',1);
  req.onupgradeneeded=()=>req.result.createObjectStore('photos',{keyPath:'id'});
  req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);
 });
 async function store(mode,fn){
  const db=await open;
  return new Promise((resolve,reject)=>{const tx=db.transaction('photos',mode),request=fn(tx.objectStore('photos'));
   tx.oncomplete=()=>resolve(request.result);tx.onabort=tx.onerror=()=>reject(tx.error);});
 }
 const all=()=>store('readonly',s=>s.getAll());
 function apply(r){if(r.image)catalog[r.id]={name:r.nameEn||r.name,he:r.nameHe||r.name,city:r.city,localImage:r.image};else delete catalog[r.id];}
 const ready=all().then(rows=>rows.forEach(apply)).catch(()=>{});
 async function resized(file){
  const url=URL.createObjectURL(file);
  try{const img=new Image();img.src=url;await img.decode();
   const scale=Math.min(1,1200/Math.max(img.width,img.height)),canvas=document.createElement('canvas');
   canvas.width=Math.max(1,Math.round(img.width*scale));canvas.height=Math.max(1,Math.round(img.height*scale));
   const ctx=canvas.getContext('2d');ctx.fillStyle='white';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(img,0,0,canvas.width,canvas.height);
   return canvas.toDataURL('image/jpeg',0.8);
  }finally{URL.revokeObjectURL(url);}
 }
 function controls(place,refresh){
  const host=document.querySelector('#photoEditor');host.replaceChildren();
  const title=document.createElement('h3'),label=document.createElement('label'),input=document.createElement('input'),status=document.createElement('p');
  title.textContent=t('photo');input.type='file';input.accept='image/*';label.append(t('choose'),input);status.setAttribute('role','status');host.append(title,label);
  for(const remove of [false,true]){
   const btn=document.createElement('button');btn.type='button';btn.textContent=t(remove?'removePhoto':'savePhoto');host.append(btn);
   btn.onclick=async()=>{if(!remove&&!input.files.length){status.textContent=t('missing');return;}
    host.disabled=true;
    try{await ready;const change={id:place.id,name:place.name,nameHe:place.nameHe,nameEn:place.nameEn,city:place.city||'',image:remove?null:await resized(input.files[0])};
     await store('readwrite',s=>s.put(change));apply(change);refresh();status.textContent=t('saved');
    }catch{status.textContent=t('failed');}finally{host.disabled=false;}
   };
  }
  host.append(status);
  host._refreshLabels=()=>{title.textContent=t('photo');label.firstChild.nodeValue=t('choose');const bs=host.querySelectorAll('button');bs[0].textContent=t('savePhoto');bs[1].textContent=t('removePhoto');status.textContent='';};
 }
 function labels(){document.querySelectorAll('[data-photo-label]').forEach(el=>el.textContent=t(el.dataset.photoLabel));}
 document.addEventListener('DOMContentLoaded',labels);window.addEventListener('maslul-languagechange',labels);
 window.photoTools={t,controls,all,ready,relabel:()=>document.querySelector("#photoEditor")?._refreshLabels?.()};
})();
